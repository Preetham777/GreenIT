


chrome.devtools.panels.create("GreenIT",
  "../icons/logo-48.png",
  "../GreenPanel.html",
  (panel) => {
    // code invoked on panel creation
  }
);
